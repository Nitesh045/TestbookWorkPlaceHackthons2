var key1 = document.getElementById("a");
var audio1 = document.getElementById("first1");
var audio2 = document.getElementById("first2");
var audio3 = document.getElementById("first3");
var audio4 = document.getElementById("first4");
var audio5 = document.getElementById("first5");
var audio6 = document.getElementById("first6");
var audio7 = document.getElementById("first7");


function start1(event){
    audio1.play();
    audio2.pause();
    audio3.pause();
    audio4.pause();
    audio5.pause();
    audio6.pause();
    audio7.pause();
   // return;
};
function start2(){
    audio2.play();
    audio1.pause();
    audio3.pause();
    audio4.pause();
    audio5.pause();
    audio6.pause();
    audio7.pause();
   // return;

};
function start3(){
    audio2.pause();
    audio1.pause();
    audio3.play();
    audio4.pause();
    audio5.pause();
    audio6.pause();
    audio7.pause();
   // return;

};
function start4(){
    audio2.pause();
    audio1.pause();
    audio3.pause();
    audio4.play();
    audio5.pause();
    audio6.pause();
    audio7.pause();
   // return;

};
function start5(){
    audio2.pause();
    audio1.pause();
    audio3.pause();
    audio4.pause();
    audio5.play();
    audio6.pause();
    audio7.pause();
   // return;

};
function start6(){
    audio2.pause();
    audio1.pause();
    audio3.pause();
    audio4.pause();
    audio5.pause();
    audio6.play();
    audio7.pause();
   // return;

};
function start7(){
    audio2.pause();
    audio1.pause();
    audio3.pause();
    audio4.pause();
    audio5.pause();
    audio6.pause();
    audio7.play();
   // return;

};

