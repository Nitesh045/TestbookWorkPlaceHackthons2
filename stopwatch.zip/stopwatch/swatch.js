var min = 0;
var sec= 0;
var tens = 0;
 
   
var timeStart = false;





 function start(){
timeStart=true;
watchnitesh();
 }
 
 
 function reset(){
    timeStart=false;
    min = 0;
    sec = 0;
    tens = 0;
    document.getElementById("min").innerHTML="00";
    document.getElementById("sec").innerHTML="00";
    document.getElementById("tens").innerHTML="00";
    

 }
  
function stop(){
    timeStart = false;
}


function watchnitesh(){
    if(timeStart==true){
        tens=tens+1
        if(tens == 100){
            sec = sec + 1;
            tens = 0;
        }
        if(sec==60){
            min = min +1;
            sec = 0 ;
        }
        document.getElementById("tens").innerHTML= tens;
        setTimeout("watchnitesh()",10);
        document.getElementById("sec").innerHTML=sec;
        document.getElementById("min").innerHTML= min;
    }
   };


